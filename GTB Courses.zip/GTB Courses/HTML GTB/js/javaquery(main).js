$(document).ready(function () {
    // id is used for particular only
    $("input").focusin(function (){ 
         $(this).css("background-color","yellow");
    });

    $("input").focusout(function (){ 
        $(this).css("background-color","white");
    });

    $("textarea").focusin(function (){ 
        $(this).css("background-color","pink");
   });

   $("textarea").focusout(function (){ 
       $(this).css("background-color","white");
   });

    $("#btn1").click(function (){ 
        $(".sam").slideDown(1000);
    });

    $("#btn2").click(function (){ 
        $(".sam").slideUp(1000);
    });

    $("#country").change(function (){ 
        var country = $(this).val();
        if(country=="india")
        {
            $("#answe").html("delhi")
        }
        else if(country=="usa")
        {
            $("#answe").html("washington")
        }
        else if(country=="canada")
        {
            $("#answe").html("ottawa")
        }
    });
    $("#simran").hover(function () {

            $("#ran").html("<h1>html is easy language</h1>"); 

        },
        function () {
            $("#ran").html("");
        }
    );

    $("#namebox1").keydown(function (e){ 
            if((e.keyCode>=65 && e.keyCode<=90)||(e.keyCode>=97&&e.keyCode<=122)||(e.keyCode==8))
            {
                length = $("#namebox1").val().length
                if(length>=100)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }
    });

    $("#namebox1").keyup(function (){ 
        $("#rr").html($("#namebox1").val().length +"/100");
    });

    $("#form1").submit(function (e) { 
       
        if($("#namebox").empty())
        {
            $("#ras").html("name is required");
        }
        
    });

    $("#btn3").click(function(){
        $("#pam").load("test.txt")

    });

}); 