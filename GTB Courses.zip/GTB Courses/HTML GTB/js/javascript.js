function changetext()
{
    document.getElementById('mymessage').innerHTML='text change by javascript'
    document.getElementById('sam').style.color='red'
}
function changecolor()
{
    mycolor=prompt("which color you want")
    document.bgColor=mycolor
}
function print()
{
    confirmation = confirm("do u really want to print?")
    if(confirmation)
    {
        window.print()
    }
}
function mygotfocus(mybox)
{
    document.getElementById(mybox).style.backgroundColor="pink"
}
function mylostfocus(mybox)
{
    document.getElementById(mybox).style.backgroundColor="white"
}
function showcapital(country)
{
    if(country=="india")
    {
        document.getElementById('s').innerHTML='delhi'
    }
    else if(country=="aus")
    {
        document.getElementById('s').innerHTML='melbourne'
    }
    else if(country=="canada")
    {
        document.getElementById('s').innerHTML='ottawa'
    }
}
function showinfo(product)
{
    if(product=="ac")
    {
        document.getElementById('sim').innerHTML='<h3>daikan 1.5 star AC</h3> we are selling it at 32000<br>buy it fast'

    }
    else if(product=="ca")
    {
        document.getElementById('sim').innerHTML='<h3>lamp is of 3 star </h3> we are selling it at 3500<br>buy it fast'
    }
}
function hideinfo()
{
    document.getElementById('sim').innerHTML=''
}
function showkey(key1)
{
    if((key1.keyCode>=65 && key1.keyCode<=90) || (key1.keyCode>=97 && key1.keyCode<=122))
    {
        return true
    }
    else
    {
        return false
    }
}
function countkey(key1)
{
    document.getElementById("ssss").innerHTML=document.getElementById("message1").value.length+" characters"
}