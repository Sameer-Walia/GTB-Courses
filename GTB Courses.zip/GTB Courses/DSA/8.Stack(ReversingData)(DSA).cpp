#include<iostream>
using namespace std;
struct node
{
	int info;
	struct node *next;
};
class stack // it follows LIFO  (last in first out)
{
	struct node *top;
	public:
		stack()
		{
		   top=NULL;
		}
		struct node *createnode()
		{
			struct node *mynode = new struct node;
			if(mynode==NULL)
			{
				cout<<"\nUnderflow";
			}
			return mynode;
		}

		bool isempty()
		{
			if(top==NULL)
			{
				//cout<<"\nUnderflow";
				return true;
			}
			return false;
		}
		void push(char ch)
		{
			struct node *newnode = createnode();
			newnode->info=ch;
			if(top==NULL) // stack was empty
			{
				top = newnode;
				newnode->next=NULL;
			}
			else
			{
				newnode->next=top;
				top=newnode;
			}
			
		}
		char pop()
		{
			if(isempty()==true)
			{
				//return; // error is coming so....
				return NULL;
			}
			struct node *temp1 , *temp2;
			temp1=top; // first node
			temp2=temp1->next; // second node
			top=temp2;
			
			char ch=temp1->info;
			delete temp1;
			
			return ch;
		}
//		void peek()
//		{
//			if(isempty())
//			{
//				return;
//			}
//			cout<<"\nElement at top is "<<top->info;
//		}
//		void traversing()
//		{
//			if(isempty())
//			{
//				return;
//			}
//			cout<<"\n==============Stack===================\n";
//			struct node *temp;
//			temp = top;
//			while(temp!=NULL)
//			{
//				cout<<temp->info<<"\n";
//				temp = temp->next;
//			}
//		}
		void input()
		{
			char st[100];
			cout<<"Enter a String : ";
			cin>>ws; // to consume white space 
			cin.getline(st,100); // c function
			int i=0; // array index starts from 0
			while(st[i]!='\0')
			{
				push(st[i]);
				i++;
			}
			cout<<"\nString Saved Successfully";
			
		}
};
int main()
{
	int ch;
	stack s1;
	while(true)
	{
		cout<<"\n====================================";
		cout<<"\n1.Input";
		cout<<"\n2.Reverse";
		cout<<"\n3.Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			s1.input();	
		}
		else if(ch==2)
		{
			cout<<"Reverse of String\n";
			while(s1.isempty()==false) // to call again and again we use while loop; otherwise only one character would be call
			{
				cout<<s1.pop()<<endl;
			}
			
		}
		else if(ch==3)
		{
			cout<<"\nExiting....";
			break;
		}
		else
		{
			cout<<"Wrong Choice";
		}
	}
	return 0;
}
