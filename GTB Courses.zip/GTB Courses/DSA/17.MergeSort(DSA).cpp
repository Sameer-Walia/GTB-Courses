// =============================Merge sort=====================================
// it is done using recursion (in this divide all elements and comapre one by one)
// recursion means when function call itself again and again
// it is a divide and conquer algorithm. It divides the into 2 halves ,call itself for 2 halves and then merge the 2 sorted halves 
#include<iostream>
using namespace std;
int merge(int arr[],int l , int m , int r)
{
	int n1 = m-l+1;
	int n2 = r-m;
	// create array
	int L[n1] , R[n2];
	//copy data to temp array
	for(int i=0 ; i<n1 ; i++)
	{
		L[i]=arr[l+i];
	}
	for(int j=0 ; j<n2 ; j++)
	{
		R[j]=arr[m+1+j];
	}
	//  merge temp array back into array
	int i=0;    // initial index of first  subarray
	int j=0;    // initial index of second subarray
	int k=l;   // initial index of merged  subarray
	while(i<n1 && j<n2)
	{
		if(L[i] <= R[j])
		{
			arr[k] = L[i];
			i++;
		}
		else
		{
			arr[k] = R[j];
			j++;
		}
		k++;
	}
	while(i<n1)   // copy the remaining elements of L[] , if there are any
	{
		arr[k] = L[i];
		i++;
		k++;
	}
	while(j<n2)   // copy the remaining elements of R[] , if there are any
	{
		arr[k] = R[j];
		j++;
		k++;
	}
}
void mergesort(int arr[] , int l , int r) // l=left r=right
{
	if(l>=r)
	{
		return;
	}
	int m = (l+r)/2;
	mergesort(arr , l , m);
	mergesort(arr , m+1 , r);
	merge(arr,l,m,r);
}
void printarray(int a[],int size)
{
	for(int i=0;i<size;i++)
	{
		cout<<a[i]<<endl;
	}
}
int main()
{
	int arr[100],arr_size,i;
	cout<<"Enter total elements : ";
	cin>>arr_size;
	cout<<"=======Enter Elements=======\n";
	for( i=0 ; i<arr_size ; i++)
	{
		cin>>arr[i];
	}
	//int a[7]={23,45,67,54,32,12,76}; // selection sort(done by mam of GTB)
	//selectionsort(a,7);
	//int arr[]={23,45,67,54,32,12,76}; // Merge sort(done by mam of GTB)
	//int arr_size =sizeof(arr)/sizeof(arr[0]); 
	//selectionsort(a,arr_size);
	cout<<"=======Elements=======\n";
	printarray(arr, arr_size);
	
	mergesort(arr , 0 , arr_size-1);
	
	cout<<"\n========Sorted Array=========\n";
	printarray(arr,arr_size);
	return 0;
}
