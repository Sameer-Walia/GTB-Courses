// Go through theory of AVL tree from pics 
// then read theory of graph(undirected , directed)
// unidirected have both forward and backword way while directed graph have only forward way
// below is undirected graph so value of mat[i][j] will also copy at mat[j][i] as it goes forward and come back
#include<iostream>
#include<iomanip>  // header file of c++
using namespace std;
void PrintMat(int mat[20][20], int n)
{
	int i , j;
	cout<<"\n\n"<<setw(4)<<""; // to get space"\t" or to get proper alignment
	for(int i=0;i<n;i++)
	{
		cout<<setw(3)<<"("<<i+1<<")";
	}
	cout<<"\n\n";
	
	for(i=0;i<n;i++)
	{
		cout<<setw(3)<<"("<<i+1<<")";
		for(j=0;j<n;j++)
		{
			cout<<setw(4)<<mat[i][j];
		}
		cout<<"\n\n";
	}
	
	
}
int main()
{
	int i,j,v;
	cout<<"Enter the number of vertices : ";
	cin>>v;
	int mat[20][20];
	cout<<"\n";
	cout<<"Enter 1 if adjacent otherwise 0 :";
	for(int i=0;i<v;i++)
	{
		for(j=i;j<v;j++)
		{
			if(i!=j)
			{
				cout<<"\nVertex "<<i+1<<" to vertex "<<j+1<<" : ";
				cin>>mat[i][j];
			
				mat[j][i] = mat[i][j];
			}
			else
			{
				mat[i][j]=0;
			}
		}
	}
	PrintMat(mat , v);
}
