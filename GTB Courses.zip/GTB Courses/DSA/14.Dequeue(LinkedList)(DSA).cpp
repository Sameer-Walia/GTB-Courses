#include<iostream>				 
using namespace std;
struct node
{
	int info;
	struct node *next;	
};
class Dequeuelinkedlist
{
	// Unlike queue , in Dequeue we can insert from front also and delete from last also ,,, 2 cases will be there(2nd case will be of queue)
	// as in queue we insert from last amd delete from first(front)
	// all same as linked list
	struct node *front , *rear;
	public: 
		Dequeuelinkedlist()
		{
			front=NULL;
			rear=NULL;
		}
		struct node *createnode()   // it means available space to make list and starting point where we insert our
									// first number and then that number will become head
		{
			//int a=new int [n]         --------------   below same code is use 
			struct node *mynode = new struct node;
			if(mynode==NULL)   // means is there any space avialable , if no then overflow or underflow
			{
				cout<<"overflow";
			}
			return mynode;
		}
		void enqueueleft()   // insert from begining
		{
			int info;
			struct node *newnode = createnode();
			cout<<"Enter Info : ";
			cin>>info;
			
			newnode->info=info;
		
			if (front==NULL)		// head is starting pint or called start pointer....
			{
				front=rear=newnode;
				newnode->next=NULL;
			}
			else
			{				
				newnode->next=front;
				front=newnode;		
			}
			cout<<"\nElement "<<newnode->info<<" inserted at Front";
		}
		void enqueueright()  //  no change same as queue (LinkedList)(DSA) beacuse we have to add element at last
		{
			int info;
			struct node *newnode = createnode();
			cout<<"Enter Info : ";
			cin>>info;
			
			newnode->info=info;
			newnode->next=NULL;
						
			if (front==NULL)		// head is starting pint or called start pointer....
			{
				front=rear=newnode;
			}
			else
			{				
				rear->next=newnode;
				rear=newnode;	
			}
			cout<<"\nElement "<<newnode->info<<" inserted at last";	
		}

		void dequeueleft()  //  no change same as queue (LinkedList)(DSA) beacuse we have to delete element from front
		{
			if(front==NULL)
			{
				cout<<"underflow";
			}
			else
			{
				struct node *temp1 , *temp2;
				temp1 = front ;///fist node
				temp2 = temp1->next;  //second node
				
				front = temp2;   // head points toward second node
				
				cout<<"Element "<<temp1->info<<" deleted successfully";
				delete temp1; //de-allocate memory
				
				if(temp2==NULL) // when only one node is left ,,, it is used because we have to pointers instead of one (rear and front)
				{				// so both have to make null when all element get deleted
					rear=NULL;	
				}
			}
		}
		void dequeueright()   // delete from end
		{
			if(front==NULL)  // no element
			{
				cout<<"underflow";
			}
			else
			{
				struct node *temp1 , *temp2;
				temp1 = front ;///fist node
				if(temp1->next==NULL)  // when only one node is there 
									//because below (while)code we have to stoped at second last node but in this code we have only one node
				{
					front=rear=NULL;
					cout<<"Element "<<temp1->info<<" deleted successfully";
					delete temp1; //de-allocate memory
				}
				else
				{
					while(temp1->next->next!=NULL) //till second last node
					{
						temp1 = temp1->next;
					}	
					temp2 = temp1->next; // last node
					temp1->next=NULL;		
					
					cout<<"Element "<<temp2->info<<" deleted from last";
					delete temp2; //de-allocate memory	
				}
				
//				if(temp2==NULL) // when only one node is left   ,,, it is used because we have to pointers instead of one (rear and front)
//				{			    // so both have to make null when all element get deleted
//					rear=NULL;	
//				}
//              this upper code is used in if statement under else
			}
		}
		
		void traversing()
		{
			if(front==NULL)
			{
				cout<<"\nUnderflow";
				return;
			}
			else
			{
				struct node *temp;
				temp=front;   // start from first node;
				
				while(temp!=NULL) // till Null of last node
				{
					cout<<temp->info<<" -> ";
					temp=temp->next;
				}				
			}
		}
	
};
int main()
{
	int ch;
	Dequeuelinkedlist a1;
	while(true)
	{
		cout<<"\n==================================";
		cout<<"\n1. Enqueue Left";
		cout<<"\n2. Enqueue Right";
		cout<<"\n3. Dequeue Left";
		cout<<"\n4. Dequeue Right";
		cout<<"\n5. Traversing";
		cout<<"\n6. Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			a1.enqueueleft();
		}
		else if(ch==2)
		{
			a1.enqueueright();
		}
		else if(ch==3)
		{
			a1.dequeueleft();
		}
		else if(ch==4)
		{
			a1.dequeueright();
		}
		else if(ch==5)
		{
			a1.traversing();
		}
		else if(ch==6)
		{
			cout<<"Exiting......";
			break;
		}
		else
		{
			cout<<"\nWrong Choice\n";
		}
	}	
	return 0;
}


