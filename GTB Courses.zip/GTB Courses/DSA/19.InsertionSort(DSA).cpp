#include<iostream>
using namespace std;
int insertionsort(int a[],int n )   
{
	for(int i=0;i<n;i++)
	{
		// storing current element whose left side is checked for its current position
		int selected_no = a[i];
		int j=i;
		while(j>0 && selected_no < a[j-1])
		{
			// moving left side element forward
			a[j] = a[j-1];
			j=j-1; //j--
		}
		// moving current element to its current position
		a[j]=selected_no;
	}
}
int main()
{
	int arr[100],arr_size,i;
	cout<<"Enter total elements : ";
	cin>>arr_size;
	cout<<"=======Enter Elements=======\n";
	for( i=0 ; i<arr_size ; i++)
	{
		cin>>arr[i];
	}
	//int a[7]={23,45,67,54,32,12,76}; // selection sort(done by mam of GTB)
	//selectionsort(a,7);
	//int arr[]={23,45,67,54,32,12,76}; // Merge sort(done by mam of GTB)
	//int arr_size =sizeof(arr)/sizeof(arr[0]); 
	//selectionsort(a,arr_size);
	insertionsort(arr, arr_size);
	
	cout<<"\n========Sorted Array=========\n";
	for( i=0 ; i<arr_size ; i++)
	{
		cout<<arr[i]<<endl;
	}
	return 0;
}
