// =============================Quick sort=====================================
// Pivot element is used(last element in list)
// it is a divide and conquer algorithm. Pivot element divides list into 2 list , all element in first sub list are smaller and in second list all are big
#include<iostream>
using namespace std;
void swap(int *a , int *b)
{
	int t;
	t=*a;
	*a=*b;
	*b=t;
}
int partition(int arr[],int low , int high )   // smaller element comes at front of pivot and bigger element come after pivot
{
	int pivot = arr[high];  // pivot is ussally last element
	int i = (low-1);   // index of smaller element which is -1
	
	for(int j=low; j<=high-1 ; j++)  // j<=high-1 minus one is used because we cannot copmare last element
	{
		// if current elemnt is smaller than pivot(last element)
		if(arr[j]<pivot) // if a[j] is bigger do nothing
		{
			i++; // increment index of smaller element
			swap(&arr[i],&arr[j]); // for swapping smaller element
		}
	}
	swap(&arr[i+1],&arr[high]);   // insert pivot element after arr[i] so that smaller and bigger sub list can be seperated
	                        //  smaller element will come at front and bigger after pivot 
	return (i+1);
}
// Main function that implement quicksort 
// arr[] = array to be sorted
//low  = starting point
//high = ending point
void quicksort(int arr[] , int low , int high) 
{
	if(low<high)  // when single element is left
	{
		// pi is partioning index,arr[p] is now at right place
		int pi = partition(arr,low,high);
		// seperatley sort element before partition and after partition
		quicksort(arr , low , pi-1);  //  pi or pivot will get sorted after upper subject 
		quicksort(arr , pi+1 , high); // recursion will take place , first partition function will perform then quicksort
	}
	
}
void printarray(int a[],int size)
{
	for(int i=0;i<size;i++)
	{
		cout<<a[i]<<endl;
	}
}
int main()
{
	int arr[100],arr_size,i;
	cout<<"Enter total elements : ";
	cin>>arr_size;
	cout<<"=======Enter Elements=======\n";
	for( i=0 ; i<arr_size ; i++)
	{
		cin>>arr[i];
	}
	//int a[7]={23,45,67,54,32,12,76}; // selection sort(done by mam of GTB)
	//selectionsort(a,7);
	//int arr[]={23,45,67,54,32,12,76}; // Merge sort(done by mam of GTB)
	//int arr_size =sizeof(arr)/sizeof(arr[0]); 
	//selectionsort(a,arr_size);
	cout<<"=======Unsorted Elements=======\n";
	printarray(arr, arr_size);
	
	quicksort(arr , 0 , arr_size-1);
	
	cout<<"\n========Sorted Array=========\n";
	printarray(arr,arr_size);
	return 0;
}
