// Floyd Warshall Algorithm
// it is used to find shortest path between every pair of vertices
#include<iostream>
using namespace std;
#define V 5  // number of vertices in the graph
#define INF 99999 // Represent infinity
void printsolution(int dist[][V])
{
	for(int i=0 ; i<V ; i++)
	{
		for(int j=0 ; j<V ; j++)
		{
			if(dist[i][j]==INF)
			{
				cout<<"INF"<<"  ";
			}
			else
			{
				cout<<dist[i][j]<<"  ";
			}
		}
		cout<<"\n";
	}
}
void floydwarshall(int graph[][V])
{
	int dist[V][V] , i , j , k;
	// copy paste to amke A0
	for(i=0 ; i<V ; i++)
	{
		for(j=0 ; j<V ; j++)
		{
			dist[i][j] = graph[i][j];
		}
	}
	for(k=0 ; k<V ; k++)   // will make A0 , A1, A2 ,A3.......
	{
		for(i=0 ; i<V ; i++)
		{
			for(j=0 ; j<V ; j++)
			{
				if(dist[i][k] + dist[k][j] < dist[i][j])  // to keep only shortest path
				{
					dist[i][j] = dist[i][k] + dist[k][j];
				}
			}
		}
	}
	printsolution(dist);
}
int main()
{
	int graph[V][V] = { {0,    3,    8,    INF,    5},
	                    {4,    0,    4,    INF,    INF},
	                    {INF,  INF,  0,    INF,    6},
	                    {7,    INF,  INF,  0,      2},
	                    {INF,  4,    INF,  3,      0},
	};
	cout<<"\n==========Given Distance============\n";
	printsolution(graph);
	cout<<"\n\n=================================\n\n";
	cout<<"\n==========Shortest Distance============\n";
	floydwarshall(graph);
	return 0;
}

