#include<iostream>
using namespace std;
#include<string.h>
#include<math.h>
class EvaluateExp
{
	public:
		int stack[100];
		int top=-1;
		
		void push(int ch)
		{
			top++;
			stack[top]=ch;
		}
		
		int pop()
		{
			int last = top;
			top--;
			return stack[last];
		}
		
		bool isempty()
		{
			if(top==-1)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		
		bool isoperator(char ch)
		{
			if(ch=='^'|| ch=='*'|| ch=='/'|| ch=='+'|| ch=='-')
			{
				return true;
			}
			return false;
		}
		
		void evaluate(char postfix_exp[])
		{
			int i=0;
			char p_ch;
			while(postfix_exp[i]!='\0')
			{
				p_ch = postfix_exp[i];
				if(isoperator(p_ch)) //operator +,-,/,*,^
				{
					int a = pop();
					int b = pop();
					int c;
					if(p_ch=='*')
					{
						c=a*b;
					}
					else if(p_ch=='/')
					{
						c=a/b;
					}
					else if(p_ch=='+')
					{
						c=a+b;
					}
					else if(p_ch=='-')
					{
						c=a-b;
					}
					else if(p_ch=='^')
					{
						c=pow (a,b);
					}
					push(c);
				}
				else  // operand
				{
					// '0' - '0' = 48-48=0
					// '1' - '0' = 49-48=1
					// '2' - '0' = 50-48=2
					// '3' - '0' = 51-48=3
					int num = p_ch - '0';
					push(num);
				}
				i++;
			}
			
			int result = pop();
			cout<<"\nResult = "<<result;
		}
};
int main()
{
	EvaluateExp ex;
	char postfix_exp[100];
	cout<<"Enter Postfix Expression : ";
	cin>>postfix_exp;
	ex.evaluate(postfix_exp);
}



















