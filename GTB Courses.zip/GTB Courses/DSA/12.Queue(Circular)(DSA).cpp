#include<iostream>
using namespace std;
class circularqueue
{
	int *a,rear,front,maxsize;
	public:
		circularqueue()
		{
			cout<<"Enter Total Size Of Queue : ";
			cin>>maxsize;
			a = new int [maxsize];
			rear=-1;
			front=-1;
		}
		bool isempty()
		{
			if(front==-1)
			{
				cout<<"\nUnderFlow";
				return true;
			}
			return false;
		}
		bool isfull()
		{
			if(front==0 && rear==(maxsize-1) || front==rear+1)     // from starting to last point || circular loop
			{
				cout<<"\nOverFlow";
				return true;
			}
			return false;
		}
		void enqueue()
		{ 
			if(isfull()==true)   //if(isfull())
			{
				return;
			}
			int el;
			cout<<"Enter a Element : ";
			cin>>el;			
			if(front==-1) // no element in queue
			{
				front++;
			}
//			else if(rear==(maxsize-1)) // was at last index but queue was not full
//			{
//				rear = (rear+1)%(maxsize);
//				assume max
//			   -1   = (-1+1)%5 = 0
//				0   = (0+1)%5  = 1
//				1   = (1+1)%5  = 2
//				2   = (2+1)%5  = 3
//				3   = (3+1)%5  = 4
//				4   = (4+1)%5  = 0
//			}
//			else
//			{
//				rear+=1;
//			}
			rear = (rear+1)%(maxsize);
			a[rear]=el;
			cout<<"\nElement Inserted Successfully";
		}
		void dequeue()
		{
			if(isempty()==true)  //if(isempty())
			{
				return;
			}
			cout<<"Element removed "<<a[front]<<" successfully";
			if(front==rear || front==(maxsize-1))
			{
				front=-1;
				rear=-1;
			}
			else
			{
				front = (front+1)%maxsize;  // its a formula
			}
			
		}
		void traversing()
		{
			if(isempty())
			{
				return ;
			}
			cout<<"\n=======Circular QUEUE=========\n";
			//for(int i=front; i<=rear ; 	rear = (rear+1)%(maxsize))
			int i;
			for( i=front; i!=rear ; i = (i+1)%(maxsize))
			{
				cout<<a[i]<<" => ";
			}
			cout<<a[i]; // to print last one
			cout<<endl;
		}
};
int main()
{
	circularqueue obj;
	int ch;
	while(1)
	{
		cout<<"\n=====Options========";
		cout<<"\n1.Enqueue";
		cout<<"\n2.Dequeue";
		cout<<"\n3.Traversing";
		cout<<"\n4.Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			obj.enqueue();
		}
		else if(ch==2)
		{
			obj.dequeue();
		}
		else if(ch==3)
		{
			obj.traversing();
		}
		else if(ch==4)
		{
			cout<<"\nExiting....";
			break;
		}
		else
		{
			cout<<"Wrong Choice..";
		}				
	}
	return 0;
}
