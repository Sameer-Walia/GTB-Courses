#include<iostream>				 
using namespace std;


struct node
{
	int info;
	struct node *next;	
};
class linkedlist
{
	struct node *head;
	public: 
		linkedlist()
		{
			head=NULL;
		}
		struct node *createnode()   // it means available space to make list and starting point where we insert our
									// first number and then that number will become head
		{
			//int a=new int [n]         --------------   below same code is use 
			struct node *mynode = new struct node;
			if(mynode==NULL)   // means is there any space avialable , if no then overflow or underflow
			{
				cout<<"overflow";
			}
			return mynode;
		}
		void InsertionAtBeg()
		{
			int newinfo;
			struct node *newnode = createnode();
			cout<<"Enter Info : ";
			cin>>newinfo;
			
			newnode->info=newinfo;
			
			if (head==NULL)		// head is starting pint or called start pointer....
			{
				head=newnode;
				newnode->next=NULL;
			}
			else
			{
				newnode->next=head;      //as head is starting point so elements will come at 1st position beacuse newnode will go to head....
								         // then newnode will come at first position and head will come at second(newnode will become head after below)
				head=newnode;			// then make newnode as head so that newelemnt will come to head(as head is first element).... and all 
								// elements will come at first position....
			}
			
			cout<<"\n-------------Node Inserted At Begining Successfully----------";
		}
	
		void InsertionAtEnd()
		{
			int info;
			struct node *newnode = createnode();
			cout<<"Enter Info : ";
			cin>>info;
			
			newnode->info=info;
			newnode->next=NULL;
						
			if (head==NULL)		// head is starting pint or called start pointer....
			{
				head=newnode;
				cout<<"\nAdding First Node";
			}
			else
			{
				struct node *temp;
				temp=head;   // start from first node;
				
				while(temp->next!=NULL) // last node
				{
					temp = temp->next;
				}
				
				temp->next=newnode;	
				cout<<"\n-------------Node Inserted At End Successfully----------";	
			}
			
		}
		void InsertionAtGivenPos()
		{
			int pos,info,total;
			
			cout<<"Enter Position : ";
			cin>>pos;
			total = getlength();
			if(pos<1 || pos>(total+1))
			{
				cout<<"\nWrong Position";
			}
			else if(pos==1)/// first position node
			{
				InsertionAtBeg();
			}
			else if(pos == (total+1))  /// last node
			{
				InsertionAtEnd();
			}
			else
			{
				int info;
				struct node *newnode = createnode();
				cout<<"Enter info : ";
				cin>>info;
				newnode->info = info;
				struct node *temp = head;
				//temp = head;
				int index = 1; // as we already are at head;
				while(index < (pos-1))
				{
					temp = temp->next;
					index++;
				}
				newnode->next = temp->next;
				temp->next = newnode;
				cout<<"\n-----Element inserted successfully-----";
			}
		}
		void DeleteFromBeg()
		{
			if(head==NULL)
			{
				cout<<"overflow";
			}
			else
			{
				struct node *temp1 , *temp2;
				temp1 = head ;///fist node
				temp2 = temp1->next;  //second node
				
				head  = temp2;
				
				cout<<"Element "<<temp1->info<<" deleted successfully";
				delete temp1; //de-allocate memory
			}
		}
		void DeleteFromEnd()
		{
			if(head==NULL)
			{
				cout<<"overflow";
			}
			else
			{
				struct node *temp1 , *temp2;
				temp1 = head; ///fist node
				if(temp1->next==NULL)  // we have only one node
				{
					head = NULL;
					cout<<"Element "<<temp1->info<<" deleted successfully";
					delete temp1; //de-allocate memory
				}
				else
				{
					while(temp1->next->next!=NULL)  // till second last node
					{
						temp1 = temp1->next;
					}
					temp2 = temp1->next; // last node
					temp1->next=NULL; // last node is removed
					
					cout<<"Element "<<temp2->info<<" deleted successfully";
					delete temp2; //de-allocate memory
				}
			}
		}
		void DeleteFromPos()
		{
			int total , pos;
			cout<<"Enter position : ";
			cin>>pos;
			
			total = getlength();
			if(total<1)
			{
				cout<<"/nOverflow";
			}
			else if(pos==1)
			{
				DeleteFromBeg();
			}
			else if(pos==total)
			{
				DeleteFromEnd();
			}
			else
			{
				struct node *temp1 = head;
				// temp1 = head ;
				int index = 1; //as we are already at head
				while(index < (pos-1)) // stop just before position
				{
					temp1 = temp1->next;
					index++;
				}
				struct node *temp2;
				
				temp2 = temp1->next; //node at given position
				temp1->next = temp2->next;
				
				cout<<"Element "<<temp2->info<<" deleted successfully";
				delete temp2; //de-allocate memory
			}
		}
		void traversing()
		{
			if(head==NULL)
			{
				cout<<"\noverflow";
				return;
			}
			else
			{
				struct node *temp;
				temp=head;   // start from first node;
				
				while(temp!=NULL) // till Null
				{
					cout<<temp->info<<" -> ";
					temp=temp->next;
				}				
			}
		}
		int getlength()
		{
			int count=0;
			struct node *temp;
			temp=head;
			
			while(temp!=NULL)
			{
				temp = temp->next;
				count++;
			}
			return count;
		}
		void searching()
		{
			// liner search
			if(head==NULL)
			{
				cout<<"\nUnderflow";
				return;
			}
			int el,pos;
			cout<<"Enter Element To Search : ";
			cin>>el;
			
			struct node *temp1;
			temp1=head;
			pos=1;
			
			while(temp1!=NULL)
			{
				if(el==temp1->info)
				{
					cout<<"Element Found At Location : "<<pos;
					break;
				}
				temp1 = temp1->next;
				pos++;
			}
			if(temp1==NULL)
			{
				cout<<"\nElement Not Found";
			}
		}
		void sorting()
		{
			if(head==NULL)
			{
				cout<<"\nUnderflow";
				return;
			}
			struct node *temp1 , *temp2;
			int thirdvar;
			temp1=head;
			while(temp1->next!=NULL)  // till last node
			{
				// we donot use (temp1->next->next!=NULL) as then we cannot compare it with last node;
				temp2 = temp1->next; // starts from temp1 adjacent node;
				while(temp2!=NULL) //till null of last node
				{
					if(temp1->info > temp2->info)
					{
						thirdvar = temp1->info;
						temp1->info = temp2->info;
						temp2->info = thirdvar;
					}
					temp2 = temp2->next;
				}
				temp1 = temp1->next ;
			}
			cout<<"\n-----List Sorted------";
		}
};
int main()
{
	int ch;
	linkedlist a1;
	while(true)
	{
		cout<<"\n==================================";
		cout<<"\n1. Insert At Beg";
		cout<<"\n2. Insert At End";
		cout<<"\n3. Insert At Given Position";
		cout<<"\n4. Deletion from Beg";
		cout<<"\n5. Deletion from End";
		cout<<"\n6. Deletion At Given Position";
		cout<<"\n7. Traversing";
		cout<<"\n8. Get Length";
		cout<<"\n9. Searching";
		cout<<"\n10.Sorting";
		cout<<"\n11.Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			a1.InsertionAtBeg();
		}
		else if(ch==2)
		{
			a1.InsertionAtEnd();
		}
		else if(ch==3)
		{
			a1.InsertionAtGivenPos();
		}
		else if(ch==4)
		{
			a1.DeleteFromBeg();
		}
		else if(ch==5)
		{
			a1.DeleteFromEnd();
		}
		else if(ch==6)
		{
			a1.DeleteFromPos();
		}
		else if(ch==7)
		{
			a1.traversing();
		}
		else if(ch==8)
		{
			int l = a1.getlength();
			cout<<"\nTotal Nodes = "<<l;
		}
		else if(ch==9)
		{
			a1.searching();
		}
		else if(ch==10)
		{
			a1.sorting();
		}
		else if(ch==11)
		{
			cout<<"Exiting......";
			break;
		}
		else
		{
			cout<<"\nWrong Choice\n";
		}
	}
	
	return 0;
}


