#include<iostream>
using namespace std;
int FindMinIndex(int arr[],int start , int end)
{
	int mini_index = start;
	for(int i= start+1 ; i<=end ; i++)
	{
		if(arr[i]<arr[mini_index])
		{
			mini_index=i;
		}
	}
	return mini_index;
}
void selectionsort(int myarr[] , int ar_size)
{
	ar_size--;
	int mini_index,picked_index,temp;
	for(int i=0;i<= ar_size;i++)
	{
		picked_index=i;
		mini_index = FindMinIndex(myarr , picked_index+1 , ar_size);
		if(myarr[picked_index] > myarr[mini_index])
		{
			/// swap
			temp = myarr[picked_index];
			myarr[picked_index] = myarr[mini_index];
			myarr[mini_index] = temp;
		}
	}
}
int main(int arr[])
{
	int a[100],n,i;
	cout<<"Enter total elements : ";
	cin>>n;
	cout<<"=======Enter Elements=======\n";
	for( i=0 ; i<n ; i++)
	{
		cin>>a[i];
	}
	//int a[7]={23,45,67,54,32,12,76}; // selection sort(done by mam of GTB)
	//selectionsort(a,7);
	//int a[]={23,45,67,54,32,12,76}; // Merge sort(done by mam of GTB)
	//int arr_size =sizeof(arr)/sizeof(arr[0]); 
	//selectionsort(a,arr_size);
	selectionsort(a,n);
	cout<<"\n--------Sorted Elements-----------\n";
	for(i=0;i<n;i++)
	{
		cout<<a[i]<<endl;
	}
	return 0;
}
