//=================BINARY TREE========================
// add any number anywhere like array
// when tree is imbalance AVL tree concept is there to balance tree
// like RR rotation , LL rotation , RL rotation , LR rotation
#include<iostream>
using namespace std;
class Binarytree
{
	int maxsize , *a ;
	public:
	Binarytree()
	{
		maxsize=7;
		a = new int[maxsize];
		for(int i=0; i<maxsize;i++)
		{
			a[i]=-1;
		}	
	}	
	void add()
	{
		int ch , pindex , info , cindex;
		
		if(a[0]==-1)
		{
			cout<<"Enter info for root node : ";   // first node or peek node
			cin>>info;
			a[0]=info;
		}
		else 
		{
			
			cout<<"Enter Parent Index : ";  // root node
			cin>>pindex;   // parent index
			if(a[pindex]==-1)
			{
				cout<<"Parent not exist";
				return ;
			}
			cout<<"\n------Add As------";
			cout<<"\n1.Left Child";
			cout<<"\n2.Right Child";
			cout<<"\nEnter Choice :";
			cin>>ch;
			if(ch==1)
			{
				cindex = 2*pindex+1;
				if(cindex > maxsize-1)
				{
					cout<<"\nLeft Child Index is not available";
				}
				else
				{
					cout<<"\nEnter information : ";
					cin>>info;
					a[cindex]=info;
				}
			}
			else if(ch==2)
			{
				cindex = 2*pindex+2;
				if(cindex > maxsize-1)
				{
					cout<<"\nRight Child Index is not available";
				}
				else
				{
					cout<<"\nEnter information : ";
					cin>>info;
					a[cindex]=info;
				}
			}
			else 
			{
				cout<<"\nInvalid choice";
			}
		}
	}
	
	void traversing()
	{
		cout<<"\n------Tree-------\n";
		for(int i=0; i<maxsize;i++)
		{
			if(a[i]==-1)
			{
				cout<<"__"<<" ";
			}
			else 
			{
				cout<<a[i];
			}
		}
		cout<<endl;
	}
}; 
int main()
{
	Binarytree t1;
	int ch;
	while(true)
	{
		cout<<"\n----Options-----";
		cout<<"\n1.Add";
		cout<<"\n2.Traversing";
		cout<<"\n3.Exit";
		cout<<"\nEnter choice : ";
		cin>>ch;
		if(ch==1)
		{
			t1.add();
		}
		else if(ch==2)
		{
			t1.traversing();
		}
		else if(ch==3)
		{
			cout<<"\nExiting";
			break;
		}
		else
		{
			cout<<"\nWrong choice....";
		}
	}
	return 0;
}
