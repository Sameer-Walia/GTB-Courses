//=================BINARY SERACH TREE====================
// binary search tree whose left child node value is less than parent node value and right child node value is bigger than parent node value
// if value is less move left side and if value is more move right side
// it is unlike binary tree because in binary tree we can add number anywhere like array
// 1.pre-order traversing(parent left right)(PLR), 2.in-order traversing(LPR) 3.Post-order traversing(LRP)
// traversing 3 types , deletion 3 types
#include<iostream>
using namespace std;
struct node
{
	int info;
	struct node *left;
	struct node *right;
};
class BST
{
	struct node *head;
	public:
	BST()
	{
		head=NULL;
	}
	struct node *createnode()
	{
		struct node *mynode = new struct node();
		if(mynode==NULL)
		{
		    cout<<"\nMemory Overflow";	
		}
		return mynode;
	}
	void add()
	{
		struct node *newnode = createnode();
		int ninfo;  // node info
		cout<<"Enter Info : ";
		cin>>ninfo;
		
		newnode->info=ninfo;
		newnode->left=NULL;
		newnode->right=NULL;
		
		if(head==NULL)  // tree was empty
		{
			head = newnode;  // adding root node or first node
		}
		else 
		{
			struct node *temp1 , *temp2;
			temp1=head;
			
			while(temp1!=NULL) // to go to null or last node by checking all node value whether small or big (comparing)
			{
				temp2=temp1;
				if(newnode->info < temp1->info)
				{
					// move left side
					temp1 = temp1->left;
				}
				else 
				{
					//move right side
					temp1= temp1->right;
				}
			}			
			if(newnode->info < temp2->info)
			{
				temp2->left = newnode;
			}
			else
			{
				temp2->right = newnode;
			}
		}
	}
	void deletion()
	{
		int val;
		cout<<"Enter node to be deleted : ";
		cin>>val;
		head = deletenode(head , val);
	}
	struct node *minValuenode(struct node *dnode)
	{
		// to find extreme left node which will take place of delete node
		struct node *current = dnode;
		// loop down to find the leftmost leaf
		while(current && current->left!=NULL)
		{
			current = current->left;
		}
		return current;
	}
	struct node *deletenode(struct node *temp1 , int key)
	{	
		if(temp1==NULL)	// base class
		{
			return temp1;
		}
		// if key is less than temp->info then move left
		if(key<temp1->info)
		{
			temp1->left = deletenode(temp1->left , key);
		}
		// if key is more than temp->info then move right
		else if(key>temp1->info )
		{
			temp1->right = deletenode(temp1->right , key);
		}
		else
		{
			if(temp1->left==NULL)
			{
				// left is null
				struct node *temp2 = temp1->right;
				delete(temp1);
				return temp2;
			}
			// right is null
			else if(temp1->right==NULL)
			{ 
				struct node *temp2 = temp1->left;
				delete(temp1);
				return temp2;
			}
			else
			{
				// node with 2 children
				struct node *temp2 = minValuenode(temp1->right);
				temp1->info = temp2->info;
				temp1->right = deletenode(temp1->right , temp2->info );
			}
		}
		return temp1;
	}
	void searching(int item)
	{
		int flag=0;
		struct node *loc,*ptr;
		ptr=head;
		while(ptr!=NULL && flag!=1)
		{
			if(item==ptr->info)
			{
				flag=1;
				loc=ptr;
			}
			else if(item > ptr->info)
			{
				ptr=ptr->right;
			}
			else
			{
				ptr=ptr->left;
			}
		}
		if(flag==1)
		{
			cout<<"item found at location : "<<loc;
		}
		else
		{
			cout<<"item not found";
		}
	}
	void traversing()
	{
		int ch;
		
		cout<<"--------Choose type-------";
		cout<<"\n1.Pre-order  traversing";
		cout<<"\n2.In-order   traversing";
		cout<<"\n3.Post-order traversing";
		cout<<"\nEnter choice : ";
		cin>>ch;
		switch(ch)
		{
			case 1:preorder(head);
			break;
			case 2:inorder(head);
			break;
			case 3:postorder(head);
			break;
			default:cout<<"\nWrong Choice";
		}			
	}
	void preorder(struct node *temp_t)  // parent left right(PLR)
	{
		if(temp_t!=NULL)
		{
			cout<<temp_t->info<<" "; // parent 
			preorder(temp_t->left);
			preorder(temp_t->right);
		}
	}
	void inorder(struct node *temp_t)  // left parent right (LPR)
	{
		if(temp_t!=NULL)
		{
			inorder(temp_t->left);
			cout<<temp_t->info<<" ";  // parent
			inorder(temp_t->right);
		}
	}
	void postorder(struct node *temp_t) //left right parent(LRP)
	{
		if(temp_t!=NULL)
		{			
			postorder(temp_t->left);
			postorder(temp_t->right);
			cout<<temp_t->info<<" ";  // parent 
		}
	}	
}; 
int main()
{
	BST t1;
	int ch;
	while(true)
	{
		cout<<"\n----Options-----";
		cout<<"\n1.Add";
		cout<<"\n2.Delete";	
		cout<<"\n3.Searching";	
		cout<<"\n4.Traversing";
		cout<<"\n5.Exit";
		cout<<"\nEnter choice : ";
		cin>>ch;
		if(ch==1)
		{
			t1.add();
		}
		else if(ch==2)
		{
			t1.deletion();
		}
		else if(ch==3)
		{
			int val;
			cout<<"Enter value to serach : ";
			cin>>val;
			t1.searching(val);
		}
		else if(ch==4)
		{
			t1.traversing();
		}
		else if(ch==5)
		{
			cout<<"\nExiting";
			break;
		}
		else
		{
			cout<<"\nWrong choice....";
		}
	}
	return 0;
}
