// Priority is a special type of queue in which each element are placed in a ascending order
// in this element is inserted according to their PNR(Priority)(in ascending order)
#include<iostream>				 
using namespace std;
struct node
{
	int info;
	int pnr;
	struct node *next;	
};
class priority
{
	// it follows FIFO
	struct node *head ;
	public: 
		priority()
		{
			head=NULL;
		}
		struct node *createnode()   // it means available space to make list and starting point where we insert our
									// first number and then that number will become head
		{
			//int a=new int [n]         --------------   below same code is use 
			struct node *mynode = new struct node;
			if(mynode==NULL)   // means is there any space avialable , if no then overflow or underflow
			{
				cout<<"overflow";
			}
			return mynode;
		}
		void inserting()
		{
			int info,pointer;
			struct node *newnode = createnode();
			cout<<"Enter Info : ";
			cin>>info;
			cout<<"Enter PNR  : ";
			cin>>pointer;
			
			newnode->info=info;
			newnode->pnr=pointer;
			
						
			if (head==NULL)		// Queue was empty
			{
				head=newnode;
				newnode->next=NULL;
				cout<<"First Node inserted successfully";
			}
			else
			{
				struct node *temp1,*temp2;
				temp1=head;  // first node
				temp2=head;
				
				if(newnode->pnr < temp1->pnr)  // to add element on front
				{
					newnode->next = temp1;
					head = newnode;
					cout<<"Node inserted at front";
				}
				else // when we have to insert in between
				{
					while(temp1!=NULL)//till null of last node
					{
						if(newnode->pnr >= temp1->pnr) 
						{
							temp2 = temp1;
							temp1 = temp1->next;
						}
						else if(newnode->pnr < temp1->pnr)
						{
							temp2->next=newnode;
							newnode->next=temp1;
							cout<<"Node inserted inbetween successfully";
							break;
						}
					}
					if(temp1==NULL) // when we have to add at last 
					{
						temp2->next=newnode;
						newnode->next=NULL;
						cout<<"Node inserted at last";
					}
				}
			}
			
		}

		void deleting()
		{
			if(head==NULL)
			{
				cout<<"underflow";
			}
			else
			{
				struct node *temp1 , *temp2;
				temp1 = head ;///fist node
				temp2 = temp1->next;  //second node
				
				head = temp2;
				
				cout<<"Element "<<temp1->info<<" deleted successfully";
				delete temp1; //de-allocate memory
			}
		}
		
		void traversing()
		{
			if(head==NULL)
			{
				cout<<"\nUnderflow";
				return;
			}
			else
			{
				struct node *temp;
				temp=head;   // start from first node;
				
				while(temp!=NULL) // till Null of last node
				{
					cout<<temp->info<<"("<<temp->pnr<<") ->";
					temp=temp->next;
				}				
			}
		}
	
};
int main()
{
	int ch;
	priority a1;
	while(true)
	{
		cout<<"\n==================================";
		cout<<"\n1. Inserting";
		cout<<"\n2. Deleting";
		cout<<"\n3. Traversing";
		cout<<"\n4. Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			a1.inserting();
		}
		else if(ch==2)
		{
			a1.deleting();
		}
		else if(ch==3)
		{
			a1.traversing();
		}
		else if(ch==4)
		{
			cout<<"Exiting......";
			break;
		}
		else
		{
			cout<<"\nWrong Choice\n";
		}
	}
	
	return 0;
}


