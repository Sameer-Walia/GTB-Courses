#include<stdio.h>
struct student
{
	char name[20];
	int marks,tmarks;
	int rn;
};
int main()
{
	int i,num,n,j,f;
	struct student s[50];
	printf("enter total students:");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		printf("===============student %d details================",i+1);
		printf("\nstudent %d name:",i+1);
		scanf("%s",&s[i].name);
		
		printf("student roll number:");
		scanf("%s",&s[i].rn);
		s[i].tmarks=0;
		
		printf("enter total subjects=");
		scanf("%d",&n);
		for(j=0;j<n;j++)
		{
		printf("enter marks of %d subject:",j+1);
		scanf("%d",&s[i].marks);
	   	s[i].tmarks+=s[i].marks;
	    }
	   	printf("total marks: %d\n",s[i].tmarks);
	   	f=(s[i].tmarks/n);
	}
	printf("\nsrno\tname\troll\tpercentage\n");
	for(i=0;i<num;i++)
	{
		printf("\n%d\t%s\t%d\t%d",i+1,s[i].name,s[i].rn,f);
	}

	return 0;
}