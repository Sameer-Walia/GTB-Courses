#include<stdio.h>
#include<conio.h>
int main()
{
	char name{50};
	int b,c,age,salary;
	
	printf("enter name:");
	scanf("%s",&name);
	
	printf("enter age:");
	scanf("%d",&age);
	
	printf("enter salary:");
	scanf("%d",&salary);
	
	if (age>=60)
	{
		printf("\n10 percent bonus is given");
		b=salary/10;
		c=salary+b;
		printf("\nsalary after 10 percent bonus is %d",c);
	}
	else if (age>=40)
	{
		printf("\n7 percent bonus is given");
		b=salary*0.07;
		c=salary+b;
		printf("\nsalary after 7 percent bonus is %d",c);
	}
	else
	{
		printf("\n5 percent bonus is given");
		b=salary*0.05;
		c=salary+b;
		printf("\nsalary after 5 percent bonus is %d",c);
	}
	return 0;
}

