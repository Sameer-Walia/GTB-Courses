#include<stdio.h>
#include<conio.h>
int main()
{
 	int num;
 
 	evensum=0;
 	oddproduct=1;
 
 	printf("enter number:");
 	scanf("%d",&num);
 
 	while(num>0)
 	{
 		if (num%2==0)
 
 		{
 			rem=num%10;
 			evensum=evensum+rem;
 			num=num/10;
 		}
 		else
 		{
 			rem=num%10;
 			oddproduct=oddproduct*rem;
 			num=num/10;
 
 		}
 
 

 	}
 
     	printf("\nsum of even digits =%d",evensum);
 	    printf("\nproduct of odd digits =%d",oddproduct);

 	return 0;
}









