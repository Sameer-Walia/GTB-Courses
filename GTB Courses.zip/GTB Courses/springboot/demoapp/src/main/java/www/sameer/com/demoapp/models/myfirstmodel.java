package www.sameer.com.demoapp.models;

public class myfirstmodel {

    String name , address , phone;

    @Override
    public String toString() {
        return "myfirstmodel [name=" + name + ", address=" + address + ", phone=" + phone + "]";
    }

    public myfirstmodel(String name, String address, String phone) {
        this.name = name;
        this.address = address;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
