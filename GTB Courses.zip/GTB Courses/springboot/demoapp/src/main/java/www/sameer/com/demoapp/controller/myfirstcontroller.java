package www.sameer.com.demoapp.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import www.sameer.com.demoapp.models.myfirstmodel;
import www.sameer.com.demoapp.services.myfirstservices;

@RestController
public class myfirstcontroller {

    @Autowired
    myfirstservices studentservice;

    @RequestMapping(value="/students" , method = RequestMethod.POST)
    public ArrayList<myfirstmodel> getstudent()
    {
        return studentservice.getstudent();
    }
    
    @PostMapping("/addstudent")
    public String savestudent(@RequestBody myfirstmodel plus)
    {
        return studentservice.savestudent(plus);
    }

    //@PostMapping("/find/{phoneno}")
    @PostMapping("/students/{phoneno}")
    public myfirstmodel findstudent(@PathVariable("phoneno") String pno)
    {
       return studentservice.findstudent(pno);
    }

    //@PutMapping("/update/{phoneno}")
    @PutMapping("/students/{phoneno}")
    public ArrayList<myfirstmodel> updatestudent(@PathVariable("phoneno") String pno , @RequestBody myfirstmodel updatestudentdata)
    {
        return studentservice.updatestudent(pno, updatestudentdata);
    }

    //@DeleteMapping("/delete/{phoneno}")
    @DeleteMapping("/students/{phoneno}")
    public ArrayList<myfirstmodel> deletestudent(@PathVariable("phoneno") String pno)
    {
        return studentservice.deletestudent(pno);
    }
    
}
