package www.sameer.com.demoapp.services;

import java.util.ArrayList;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import www.sameer.com.demoapp.models.myfirstmodel;

@Service

public class myfirstservices {
    
     myfirstmodel  onestudent;
    ArrayList<myfirstmodel> student = new ArrayList<>();

    public myfirstservices()
    {
        student.add(new myfirstmodel("sameer", "model-town", "7719690306"));
        student.add(new myfirstmodel("rahul", "urban-state", "867658758"));
        student.add(new myfirstmodel("abhi", "basti-sheikh", "798695777"));
    }

    public ArrayList<myfirstmodel> getstudent()
    {
        System.out.print(student);  // while running below
        return student;
    }

    @PostMapping("/addstudent")
    public String savestudent(@RequestBody myfirstmodel plus)
    {
        student.add(plus);
        return "student added successfully";
    }

    //@PostMapping("/find/{phoneno}")
    @PostMapping("/students/{phoneno}")
    public myfirstmodel findstudent(@PathVariable("phoneno") String pno)
    {
        onestudent = student.stream()
        .filter(onestudent -> pno.equals(onestudent.getPhone()))
        .findAny()
        .orElse(new myfirstmodel("not found", "not found", "not found"));
        
        return onestudent;
    }

    //@PutMapping("/update/{phoneno}")
    @PutMapping("/students/{phoneno}")
    public ArrayList<myfirstmodel> updatestudent(@PathVariable("phoneno") String pno , @RequestBody myfirstmodel updatestudentdata)
    {
        onestudent = student.stream()
        .filter(onestudent -> pno.equals(onestudent.getPhone()))
        .findAny()
        .orElse(new myfirstmodel("not found", "not found", "not found"));
        
        student.set(student.indexOf(onestudent) , updatestudentdata);
        return student;
    }

    //@DeleteMapping("/delete/{phoneno}")
    @DeleteMapping("/students/{phoneno}")
    public ArrayList<myfirstmodel> deletestudent(@PathVariable("phoneno") String pno)
    {
       student.removeIf(student -> pno.equals(student.getPhone()));      
       return student;
    }

}
